package com.treez.orderservice.cntrl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.treez.orderservice.model.Inventory;

public class InventoryControllerTest extends AbstractTest {
	@Override
	@Before
	public void setUp() {
		super.setUp();
	}

	@Test
	public void testGetAllInventories() throws Exception {
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.get("/inventories").accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Inventory[] inventories = super.mapFromJson(content, Inventory[].class);
		assertTrue(inventories.length > 0);
	}

	@Test
	public void testGetInventoryById() throws Exception {
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.get("/inventories/3").accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Inventory inventories = super.mapFromJson(content, Inventory.class);
		assertTrue(inventories.getId() == 3);
	}

	@Test
	public void testUpdateInventory() throws Exception {
		Inventory inventory = new Inventory();
		inventory.setId(3);
		inventory.setItemName("Philips");
		inventory.setItemsQuantity(3);
		inventory.setPrice(300.89);

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.put("/inventories/3")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(inventory))).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	public void testSaveAllInventory() throws Exception {
		List<Inventory> inventories = new ArrayList<Inventory>();
		Inventory inventory = new Inventory();
		inventory.setId(6);
		inventory.setItemName("Max");
		inventory.setItemsQuantity(3);
		inventory.setPrice(300.89);

		Inventory inventory1 = new Inventory();
		inventory1.setId(7);
		inventory1.setItemName("Philips");
		inventory1.setItemsQuantity(3);
		inventory1.setPrice(300.89);

		inventories.add(inventory1);
		inventories.add(inventory);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post("/inventories")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(inventories))).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);

	}

	@Test
	public void deleteOrder() throws Exception {
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.delete("/inventories/1").contentType(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}
}
