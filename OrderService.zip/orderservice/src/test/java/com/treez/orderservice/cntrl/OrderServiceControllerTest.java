package com.treez.orderservice.cntrl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.treez.orderservice.model.Order;

public class OrderServiceControllerTest extends AbstractTest{
	@Override
	@Before
	public void setUp() {
		super.setUp();
	}
	
	
	@Test
	public void testGetAllOrders() throws Exception {
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.get("/orders").accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Order[] mapFromJson = super.mapFromJson(content, Order[].class);
		assertTrue(mapFromJson.length >0);
	}
	
	@Test
	public void testGetOrder() throws Exception{
		MvcResult mvcResult = mvc
				.perform(MockMvcRequestBuilders.get("/orders/2").accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Order mapFromJson = super.mapFromJson(content, Order.class);
		assertTrue(mapFromJson.getId()==2);
	}
	
	@Test
	public void testUpdateOrder() throws Exception{
		Order order= new Order();
		order.setId(1);
		order.setItemName("sony");
		order.setMailId("abc@h.com");
		order.setOrderDate(new Date());
		order.setStatus("Ready For dispatch");
		
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.put("/orders/1")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(order))).andReturn();
	int status = mvcResult.getResponse().getStatus();
	assertEquals(200, status);
	}
	
	@Test
	public void deleteOrder() throws Exception{
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete("/orders/1")
				.contentType(MediaType.APPLICATION_JSON_VALUE)).andReturn();
	int status = mvcResult.getResponse().getStatus();
	assertEquals(200, status);
	}
	
	@Test
	public void testSaveOrders() throws Exception{
		List<Order> orders = new ArrayList<Order>();
		Order order= new Order();
		order.setId(6);
		order.setItemName("sony");
		order.setMailId("abc@h.com");
		order.setOrderDate(new Date());
		order.setStatus("Ready For dispatch");
		
		Order order1= new Order();
		order1.setId(7);
		order1.setItemName("lg");
		order1.setMailId("abc@h.com");
		order1.setOrderDate(new Date());
		order1.setStatus("Ready For dispatch");
		
		orders.add(order);
		orders.add(order1);
		
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post("/orders")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(orders))).andReturn();
	int status = mvcResult.getResponse().getStatus();
	assertEquals(200, status);
	}
}
