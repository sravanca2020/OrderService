package com.treez.orderservice.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.treez.orderservice.model.Inventory;

@Repository
public interface InventoryRepository extends CrudRepository<Inventory, Serializable> {
Inventory findByItemName(String inventoryName);
}
