/*
 * package com.treez.orderservice.dto;
 * 
 * public class InventoryItem { private long id; private String itemName;
 * private long itemsQuantity; private double price;
 * 
 * public long getId() { return id; }
 * 
 * public void setId(long id) { this.id = id; }
 * 
 * public String getItemName() { return itemName; }
 * 
 * public void setItemName(String itemName) { this.itemName = itemName; }
 * 
 * public long getItemsQuantity() { return itemsQuantity; }
 * 
 * public void setItemsQuantity(long itemsQuantity) { this.itemsQuantity =
 * itemsQuantity; }
 * 
 * public double getPrice() { return price; }
 * 
 * public void setPrice(double price) { this.price = price; }
 * 
 * }
 */