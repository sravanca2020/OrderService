package com.treez.orderservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.treez.orderservice.model.Inventory;
import com.treez.orderservice.repository.InventoryRepository;

@Service
public class InventoryService {
@Autowired
private InventoryRepository inventoryRepository;

public List<Inventory> getAllInventory(){
	List<Inventory> inventories = new ArrayList<Inventory>();
	inventoryRepository.findAll().forEach(inventories::add);;
	return inventories;
}

public Inventory getInventory(long id){
	return inventoryRepository.findOne(id);
}

public void saveAllInventory(List<Inventory> inventories) {
	inventoryRepository.save(inventories);
}

public void updateInventory(Inventory inventory) {
	inventoryRepository.save(inventory);
}

public void deleteInventory(long id) {
	inventoryRepository.delete(id);
}

public Inventory getItemInventory(String name) {
	return inventoryRepository.findByItemName(name);
}
}
