package com.treez.orderservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.treez.orderservice.model.Order;
import com.treez.orderservice.repository.OrderRepository;

@Service
public class OrderService {
@Autowired
private OrderRepository orderRepository;

public List<Order> getAllOrders(){
	List<Order> orders = new ArrayList<Order>();
	orderRepository.findAll().forEach(orders::add);
	return orders;
}

public Order getOrders(long id) {
	return orderRepository.findOne(id);
}

public void saveAllOrders(List<Order> orders) {
	orderRepository.save(orders);
}

public void updateOrder(Order order) {
	orderRepository.save(order);
}

public void deleteOrder(long id) {
	orderRepository.delete(id);
}
}
