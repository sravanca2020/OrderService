package com.treez.orderservice.cntrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.treez.orderservice.model.Inventory;
import com.treez.orderservice.service.InventoryService;

@RestController
@RequestMapping("/inventories")
public class InventoryController {
	@Autowired
	private InventoryService inventoryService;

	@GetMapping
	public List<Inventory> getAllInvetoryItems() {
		return inventoryService.getAllInventory();
	}

	@GetMapping("/{id}")
	public Inventory getInventoryItem(@PathVariable(value = "id") long id) {
		return inventoryService.getInventory(id);
	}

	@PutMapping("/{id}")
	public void updateInvetoryItem(@PathVariable(value = "id") long id, @RequestBody Inventory newItem) {
		inventoryService.updateInventory(newItem);
	}

	@DeleteMapping("/{id}")
	public String deleteItem(@PathVariable(value = "id") long id) {
		inventoryService.deleteInventory(id);
		return "deleted successfully";
	}

	@PostMapping
	public void createItems(@RequestBody List<Inventory> newItems) {
		inventoryService.saveAllInventory(newItems);
	}

}
