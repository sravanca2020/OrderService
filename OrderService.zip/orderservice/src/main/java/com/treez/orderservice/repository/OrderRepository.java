package com.treez.orderservice.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.treez.orderservice.model.Order;

@Repository
public interface OrderRepository extends CrudRepository<Order, Serializable>{

}