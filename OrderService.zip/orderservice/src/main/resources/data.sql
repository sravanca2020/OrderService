insert into inventory values (1, 'sony',10,200.35);
insert into inventory values (2, 'toshiba',10,200.35);
insert into inventory values (3, 'lg',10,150.35);
insert into inventory values (4, 'apple',10,800.35);


insert into order_item values(1,'abc@g.com',CURRENT_TIMESTAMP(),'dispatched','sony');
insert into order_item values(2,'fgh@a.com',CURRENT_TIMESTAMP(),'ready for dispatch','toshiba');
insert into order_item values(3,'jkl@b.com',CURRENT_TIMESTAMP(),'in inventory','apple')